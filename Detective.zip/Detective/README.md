# Detective
Application mobile of crimes
Este es el trabajo en clase de la materia de programacion movil, la aplicacion es una lista de crimenes.
